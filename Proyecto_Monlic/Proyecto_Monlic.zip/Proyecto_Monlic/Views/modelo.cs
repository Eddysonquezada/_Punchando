﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Proyecto_Monlic.Views
{
    public class modelo
    {
        public Models.Entradas_Salidas entrada { get; set; }
        public Models.Movimientos movimiento { get; set; }
    }
}